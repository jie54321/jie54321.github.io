import React from "react";
export const metadata  = {
    title: '任务详情 | love-trick',
    description: 'love-trick',
}
export default function TaskInfoLayout({children}) {
    return <section>{children}</section>
}
