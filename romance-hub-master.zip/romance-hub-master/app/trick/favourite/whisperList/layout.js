import React from "react";
export const metadata  = {
    title: 'Whisper | love-trick',
    description: 'love-trick',
}
export default function WhisperLayout({children}) {
    return <>{children}</>
}
