import React from "react";
export const metadata  = {
    title: '我的信息 | love-trick',
    description: 'love-trick',
}
export default function MyInfoLayout({children}) {
    return <>{children}</>
}
