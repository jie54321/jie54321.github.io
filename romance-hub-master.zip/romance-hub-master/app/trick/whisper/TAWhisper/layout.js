import React from "react";
export const metadata  = {
    title: 'TA的留言 | love-trick',
    description: 'love-trick',
}
export default function WhisperLayout({children}) {
    return <>{children}</>
}
