import React from "react";
export const metadata  = {
    title: '我的礼物 | love-trick',
    description: 'love-trick',
}
export default function GiftLayout({children}) {
    return <>{children}</>
}
