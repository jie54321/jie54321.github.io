import React from "react";
export const metadata  = {
    title: '新增礼物 | love-trick',
    description: 'love-trick',
}
export default function AddGiftLayout({children}) {
    return <>{children}</>
}
