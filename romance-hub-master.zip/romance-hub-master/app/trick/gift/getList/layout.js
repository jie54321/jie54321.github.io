import React from "react";
export const metadata  = {
    title: '礼物列表 | love-trick',
    description: 'love-trick',
}
export default function GetGiftLayout({children}) {
    return <>{children}</>
}
