import React from "react";
export const metadata  = {
    title: '发布任务 | love-trick',
    description: 'love-trick',
}
export default function PostTaskLayout({children}) {
    return <>{children}</>
}
